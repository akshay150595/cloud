
const express = require('express')
const route = express.Router()
const property = require('../middleware/redis-middleware.js')
const appConfig = require('../middleware/config.js')

route.get('/getFullName',async (req,res) =>{
    res.status(200).json({'FullName': await property.getProperty('firstName') + ' ' + await property.getProperty('lastName')})
})

route.get('/getFirstName',async (req,res) =>{
    res.status(200).json({'FirstName':await property.getProperty('firstName') })
})

route.get('/getLastName',async (req,res) =>{
    res.status(200).json({'LastName': await property.getProperty('lastName')})
})

route.get('/getAppConfig',async (req,res) =>{
    res.status(200).json({'appConfig': appConfig})
})

module.exports = route;