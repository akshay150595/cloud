const redis = require('redis')
const appConfig  = require('./config.js')
const path = require('path')

const client = redis.createClient({
    port: 6379, // replace with your port
    host: '127.0.0.1'
})


exports.getProperty = (key) => {
    return new Promise( (resolve, reject) => {
        if(appConfig['env'] == 'dev'){
            const PropertiesReader = require('properties-reader')
            let propPath = path.join(__dirname + '/localproperties.file')
            const properties = PropertiesReader(propPath)
            resolve(properties.get(key))
        } else {
            getValue(client, 'testProject:bapi', key).then(value => {
                resolve(value)
            })
        }
         
    })
}

function getValue(client, hash, key) {
    return new Promise( (resolve, reject) => {
         client.hget(hash, key, function (err, resp) {
            if (err) {
                resolve(null)
            } else {
                resolve(resp)
            }
        })
    })
}