const PropertiesReader = require('properties-reader')
const path = require('path')
const env = process.env.ENV || "dev"
const property = require('./redis-middleware.js')

let propPath = ''
if(env === "dev"){
    propPath = path.join(__dirname + '/properties.file')
} else {
    propPath = 'D:\\Project\\properties.file'
}
const properties = PropertiesReader(propPath)

let appConfig = {}
appConfig['env'] = env

appConfig['redisUrl'] = properties.get('redis.host')
appConfig['redisPort'] = properties.get('redis.port')




//appConfig['firstName'] =  ( (property.getProperty('firstNamee') === null) ? 'gagan' : 'akshay')
module.exports = appConfig