const NodeCache = require('node-cache')
const globalCache = new NodeCache();

exports.save = (key,value) =>{
    return globalCache.set(key,value);
}

exports.find = (key) =>{
    return globalCache.get(key);
}

exports.hasKey = (key) =>{
    return globalCache.has(key);
}